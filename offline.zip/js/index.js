/*
    * LOVELY THINGS
    */

              

var options = {
  valueNames: [ 'name', 'description', 'category', 'thumb' ]
};

var featureList = new List('externship-sites', options);

$('#filter-breakfast').click(function() {
  featureList.filter(function(item) {
    if (item.values().category == "breakfast") {
      return true;
    } else {
      return false;
    }
  });
  return false;
});

$('#filter-lunch').click(function() {
  featureList.filter(function(item) {
    if (item.values().category == "lunch") {
      return true;
    } else {
      return false;
    }
  });
  return false;
});

$('#filter-dinner').click(function() {
  featureList.filter(function(item) {
    if (item.values().category == "dinner") {
      return true;
    } else {
      return false;
    }
  });
  return false;
});

$('#filter-Chinese').click(function() {
  featureList.filter(function(item) {
    if (item.values().category == "Chinese") {
      return true;
    } else {
      return false;
    }
  });
  return false;
});

$('#filter-Geek').click(function() {
  featureList.filter(function(item) {
    if (item.values().category == "Geek") {
      return true;
    } else {
      return false;
    }
  });
  return false;
});

$('#filter-Lebanese').click(function() {
  featureList.filter(function(item) {
    if (item.values().category == "Lebanese") {
      return true;
    } else {
      return false;
    }
  });
  return false;
});

$('#filter-Coffee').click(function() {
  featureList.filter(function(item) {
    if (item.values().category == "Coffee") {
      return true;
    } else {
      return false;
    }
  });
  return false;
});

$('#filter-Desi').click(function() {
  featureList.filter(function(item) {
    if (item.values().category == "Desi") {
      return true;
    } else {
      return false;
    }
  });
  return false;
});

$('#filter-Italian').click(function() {
  featureList.filter(function(item) {
    if (item.values().category == "Italian") {
      return true;
    } else {
      return false;
    }
  });
  return false;
});

$('#filter-Mexican').click(function() {
  featureList.filter(function(item) {
    if (item.values().category == "Mexican") {
      return true;
    } else {
      return false;
    }
  });
  return false;
});

$('#filter-Continental').click(function() {
  featureList.filter(function(item) {
    if (item.values().category == "Continental") {
      return true;
    } else {
      return false;
    }
  });
  return false;
});

$('#filter-none').click(function() {
  featureList.filter();
  return false;
});

if('serviceWorker' in navigator) {
    navigator.serviceWorker
             .register('service-worker.js')
             .then(function() { console.log('Service Worker Registered'); });
  }