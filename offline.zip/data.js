{
"records":[
{"Dish":"Alfreds Futterkiste1","Phone":"01234567890", "Restaurant":"Riders Republic Cafe","Address":"Vijay Nagar › 81, Near RR Tyres, Sayaji Club Road, Bhamori, Vijay Nagar, Indore", "budget":"700","card":"accepted", "attraction":"Vintage themed ambience" },
{"Dish":"Alfreds Futterkiste2","Phone":"01234567890", "Restaurant":"Riders Republic Cafe","Address":"Vijay Nagar › 81, Near RR Tyres, Sayaji Club Road, Bhamori, Vijay Nagar, Indore", "budget":"700","card":"accepted", "attraction":"Vintage themed ambience" },
{"Dish":"Alfreds Futterkiste3","Phone":"01234567890", "Restaurant":"Riders Republic Cafe","Address":"Vijay Nagar › 81, Near RR Tyres, Sayaji Club Road, Bhamori, Vijay Nagar, Indore", "budget":"700","card":"accepted", "attraction":"Vintage themed ambience" },
{"Dish":"Alfreds Futterkiste4","Phone":"01234567890", "Restaurant":"Riders Republic Cafe","Address":"Vijay Nagar › 81, Near RR Tyres, Sayaji Club Road, Bhamori, Vijay Nagar, Indore", "budget":"700","card":"accepted", "attraction":"Vintage themed ambience" },
{"Dish":"Alfreds Futterkiste5","Phone":"01234567890", "Restaurant":"Riders Republic Cafe","Address":"Vijay Nagar › 81, Near RR Tyres, Sayaji Club Road, Bhamori, Vijay Nagar, Indore", "budget":"700","card":"accepted", "attraction":"Vintage themed ambience" },
{"Dish":"Alfreds Futterkiste6","Phone":"01234567890", "Restaurant":"Riders Republic Cafe","Address":"Vijay Nagar › 81, Near RR Tyres, Sayaji Club Road, Bhamori, Vijay Nagar, Indore", "budget":"700","card":"accepted", "attraction":"Vintage themed ambience" },
{"Dish":"Alfreds Futterkiste7","Phone":"01234567890", "Restaurant":"Riders Republic Cafe","Address":"Vijay Nagar › 81, Near RR Tyres, Sayaji Club Road, Bhamori, Vijay Nagar, Indore", "budget":"700","card":"accepted", "attraction":"Vintage themed ambience" },
{"Dish":"Alfreds Futterkiste8","Phone":"01234567890", "Restaurant":"Riders Republic Cafe","Address":"Vijay Nagar › 81, Near RR Tyres, Sayaji Club Road, Bhamori, Vijay Nagar, Indore", "budget":"700","card":"accepted", "attraction":"Vintage themed ambience" },
{"Dish":"Alfreds Futterkiste9","Phone":"01234567890", "Restaurant":"Riders Republic Cafe","Address":"Vijay Nagar › 81, Near RR Tyres, Sayaji Club Road, Bhamori, Vijay Nagar, Indore", "budget":"700","card":"accepted", "attraction":"Vintage themed ambience" },
{"Dish":"Alfreds Futterkiste10","Phone":"01234567890", "Restaurant":"Riders Republic Cafe","Address":"Vijay Nagar › 81, Near RR Tyres, Sayaji Club Road, Bhamori, Vijay Nagar, Indore", "budget":"700","card":"accepted", "attraction":"Vintage themed ambience" }
]
} 
